package fpt.edu.fumic.database.model;

public interface Category {

    int getId();
    String getName();

}
