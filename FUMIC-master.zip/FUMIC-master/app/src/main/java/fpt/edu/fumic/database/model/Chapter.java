package fpt.edu.fumic.database.model;

public interface Chapter {

    int getBookId();
    String getContent();
    int getChapterNo();
    String getChapterTitle();


}
