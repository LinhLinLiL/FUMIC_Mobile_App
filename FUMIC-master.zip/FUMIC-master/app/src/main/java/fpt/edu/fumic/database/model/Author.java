package fpt.edu.fumic.database.model;

public interface Author {
    public int getId();
    public String getName();
    public int getAge();
    public String getInformation();

}
